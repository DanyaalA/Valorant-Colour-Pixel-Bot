﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CBVDGUI
{
    public partial class Recorder : Form
    {
        private int w, h;
        public Recorder(int width, int height)
        {
            w = width;
            h = height;
            InitializeComponent();
        }

        public Image ScaleImage(Image image, int maxWidth, int maxHeight)
        {
            var ratioX = (double)maxWidth / image.Width;
            var ratioY = (double)maxHeight / image.Height;
            var ratio = Math.Min(ratioX, ratioY);

            var newWidth = (int)(image.Width * ratio);
            var newHeight = (int)(image.Height * ratio);

            var newImage = new Bitmap(maxWidth, maxHeight);
            using (var graphics = Graphics.FromImage(newImage))
            {
                // Calculate x and y which center the image
                int y = (maxHeight / 2) - newHeight / 2;
                int x = (maxWidth / 2) - newWidth / 2;

                // Draw image on x and y with newWidth and newHeight
                graphics.DrawImage(image, x, y, newWidth, newHeight);
            }

            return newImage;
        }

        public static Bitmap ReSizeImage(Bitmap ImageToReSize, Size s)
        {
            // An empty bitmap which will hold the cropped image
            Bitmap bmp = new Bitmap(s.Width, s.Height);
            //Rectangle section = new Rectangle(new Point(s.Width / 2, s.Height / 2), new Size(ImageToReSize.Width, ImageToReSize.Height));

            Rectangle section = new Rectangle(new Point(s.Width / 2, s.Height / 2), new Size(ImageToReSize.Width, ImageToReSize.Height));

            Graphics g = Graphics.FromImage(bmp);

            // Draw the given area (section) of the source image
            // at location 0,0 on the empty bitmap (bmp)
            g.DrawImage(ImageToReSize, s.Width / 2, s.Height / 2, section, GraphicsUnit.Pixel);
            // MessageBox.Show($"Text Height: {bmp.Width}x{bmp.Height}");
            return bmp;
        }

        private void CaptureScreen()
        {
            Rectangle screenSize = Screen.PrimaryScreen.Bounds;
            Size Size = new Size(screenSize.Width, screenSize.Height);



            while (true)
            {
                Bitmap target = new Bitmap(screenSize.Width, screenSize.Height);

                //target = ReSizeImage(target, Size);

                using (Graphics g = Graphics.FromImage(target))
                {

                    g.CopyFromScreen(Size.Width / 2, Size.Height /2, 0, 0, Size);
                    using (Image prev_bitmap = pictureBox1.Image)
                    {
                        pictureBox1.Image = target;
                    }
                }


                //Thread.Sleep(50);
            }

            // return target;
        }
        private void Recorder_Load(object sender, EventArgs e)
        {
            pictureBox1.Size = new Size(w, h);
            pictureBox1.Location = new Point(0, 0);
            Size = new Size(w, h);

            Thread x2 = new Thread(CaptureScreen);
            x2.SetApartmentState(ApartmentState.STA);
            x2.Start();
        }
    }
}
