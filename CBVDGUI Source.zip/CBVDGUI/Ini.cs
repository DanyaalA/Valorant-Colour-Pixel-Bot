﻿using IniParser;
using IniParser.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBVDGUI
{
    class Ini
    {
        public void CreateIni()
        {
            if (!File.Exists("config.ini"))
            {
                FileStream fs = File.Create("config.ini");
                fs.Dispose();
                Writer();
            }

        }
        public Config Reader()
        {
            Config conf = new Config();
            try
            {
                var parser = new FileIniDataParser();
                IniData data = parser.ReadFile("config.ini");

                

                conf.FOV = Convert.ToDecimal(data["Aim"]["FOV"]);
                conf.Speed = float.Parse(data["Aim"]["Speed"]);
                conf.ShootDelay = Convert.ToInt32(data["Aim"]["Shoot Delay"]);
                conf.SnapDelay = Convert.ToInt32(data["Aim"]["Snap Delay"]);
                conf.AutoShoot = bool.Parse(data["Aim"]["Auto Shoot"]);
                conf.AimKey = data["Aim"]["Aim Key"];

                conf.Width = Convert.ToInt32(data["General"]["Width"]);
                conf.Height = Convert.ToInt32(data["General"]["Height"]);
                conf.Bhop = bool.Parse(data["General"]["Bhop"]);
                return conf;
            }
            catch
            {
                if (File.Exists("config.ini"))
                {
                    FileStream fs = File.Create("config.ini");
                    fs.Dispose();
                    Writer();
                    return Reader();
                }

            }


            return conf;
        }

        public void Writer()
        {
            var parser = new FileIniDataParser();
            IniData data = parser.ReadFile("config.ini");


            data.Sections.AddSection("Aim");
            data["Aim"].AddKey("FOV", "150");
            data["Aim"].AddKey("Speed", "1.1");
            data["Aim"].AddKey("Shoot Delay", "200");
            data["Aim"].AddKey("Snap Delay", "100");
            data["Aim"].AddKey("Auto Shoot", "true");
            data["Aim"].AddKey("Aim Key", "LALT");

            data.Sections.AddSection("General");
            data["General"].AddKey("Width", "1920");
            data["General"].AddKey("Height", "1080");
            data["General"].AddKey("Bhop", "false");

            parser.WriteFile("config.ini", data);
        }

        public void Writer(Config cfg)
        {
            var parser = new FileIniDataParser();
            IniData data = parser.ReadFile("config.ini");

            data["Aim"]["FOV"] = cfg.FOV.ToString();
            data["Aim"]["Speed"] = cfg.Speed.ToString();
            data["Aim"]["Shoot Delay"] = cfg.ShootDelay.ToString();
            data["Aim"]["Snap Delay"] = cfg.SnapDelay.ToString();
            data["Aim"]["Auto Shoot"] = cfg.AutoShoot.ToString(); ;
            data["Aim"]["Aim Key"] = cfg.AimKey.ToString();

            data["General"]["Width"] = cfg.Width.ToString();
            data["General"]["Height"] = cfg.Height.ToString();
            data["General"]["Bhop"] = cfg.Bhop.ToString();

            parser.WriteFile("config.ini", data);
        }
    }

    class Config
    {
        public decimal FOV { get; set; }
        public float Speed { get; set; }
        public int ShootDelay { get; set; }
        public int SnapDelay { get; set; }
        public bool AutoShoot { get; set; }
        public string AimKey { get; set; }
        public int Width { get; set; }

        public int Height { get; set; }
        public bool Bhop { get; set; }

    }
}

