﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Reflection.Emit;

namespace CBVDGUI
{
    public partial class Main : Form
    {
        bool started = false;
        public static Thread botThread = new Thread(Bot.Run);
        Config cfg = new Config();
        public Main()
        {
            InitializeComponent();
        }

        private void checker()
        {
            bool on = true;
            int secs = 0;
            while (on)
            {

                bool xx = Peripherals.Mouse.MouseButtonIsDown(1);

                if (xx)
                    Console.WriteLine("Yess");

                secs++;
                if (secs > 5000)
                    on = false;
            }
        }

        public static string RandomString(int length)
        {
            Random random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        


        private void Main_Load(object sender, EventArgs e)
        {


            Name = RandomString(16);
            Text = RandomString(16);

            

            Thread xx = new Thread(checker);
            xx.SetApartmentState(ApartmentState.STA);
            xx.Start();



            Width = GeneralPanel.Width + 25;
            //Height = 385;

            AimPanel.Location = GeneralPanel.Location;


            GeneralPanel.BringToFront();
            GeneralPanel.Visible = true;
            AimPanel.Visible = false;


            Ini ini = new Ini();

            ini.CreateIni(); //Incase File Doesnt Exist

            cfg = ini.Reader();

            LoadConfig(cfg);
        }

        private void LoadConfig(Config cfg)
        {
            resWidthBox.Text = cfg.Width.ToString();
            resHeightBox.Text = cfg.Height.ToString();

            FOVBox.Text = cfg.FOV.ToString();
            SpeedBox.Text = cfg.Speed.ToString();
            ShootDelayBox.Text = cfg.ShootDelay.ToString();
            SnapDelayBox.Text = cfg.SnapDelay.ToString();

            if (cfg.AutoShoot)
                AutoShootCheck.Checked = true;
            else
                AutoShootCheck.Checked = false;

            if (AimKeyCombo.Items.Contains(cfg.AimKey))
                AimKeyCombo.SelectedItem = cfg.AimKey;
            else
                AimKeyCombo.SelectedIndex = 0;


        }

        private static EventWaitHandle waitHandle = new ManualResetEvent(initialState: true);

        // Main thread
        public void OnPauseClick()
        {
            waitHandle.Reset();
        }

        public void OnResumeClick()
        {
            waitHandle.Set();
        }


        private void SaveConfig()
        {
            cfg.Width = Convert.ToInt32(resWidthBox.Text);
            cfg.Height = Convert.ToInt32(resHeightBox.Text);
            cfg.Bhop = AutoBhopCheck.Checked;


            cfg.FOV = Convert.ToDecimal(FOVBox.Text);
            cfg.Speed = float.Parse(SpeedBox.Text);
            cfg.ShootDelay = Convert.ToInt32(ShootDelayBox.Text);
            cfg.SnapDelay = Convert.ToInt32(SnapDelayBox.Text);

            if (AutoShootCheck.Checked)
                cfg.AutoShoot = true;
            else
                cfg.AutoShoot = false;


            cfg.AimKey = AimKeyCombo.SelectedItem.ToString();

            Ini ini = new Ini();
            ini.Writer(cfg);
        }

        private void SuperButton_Click(object sender, EventArgs e)
        {

            started = !started;

            SaveConfig();
            

            if (started)
            {
                Ini ini = new Ini();

                ini.CreateIni(); //Incase File Doesnt Exist

                cfg = ini.Reader();

                int FOVX = Convert.ToInt32(cfg.FOV * cfg.Width);
                int FOVY = Convert.ToInt32(cfg.FOV * cfg.Height);

                Recorder rc = new Recorder(FOVX, FOVY);
                rc.Show();

                //Console.WriteLine(SuperButton.SuperSelected);
                SuperButton.ButtonText = "Stop";
                SuperButton.SuperSelected = true;
                Bot.Enabled = true;
                Bot.Run();
                
                //botThread.Start();
            }
            else
            {
                FormCollection fc = Application.OpenForms;
                Form f = new Form();

                foreach (Form frm in fc)
                {
                    //iterate through
                    if (frm.Name == "Recorder")
                    {
                        f = frm;
                    }
                }

                f.Close();

                SuperButton.ButtonText = "Start";
                SuperButton.SuperSelected = false;
                Bot.Enabled = false;
                //botThread.Suspend();
            }
        }

        private void MainSegment_Click(object sender, EventArgs e)
        {
            if (MainSegment.SelectedIndex == 0)
            {
                GeneralPanel.BringToFront();
                GeneralPanel.Visible = true;
                AimPanel.Visible = false;
            }
            else if (MainSegment.SelectedIndex == 1)
            {
                AimPanel.BringToFront();
                AimPanel.Visible = true;
                GeneralPanel.Visible = false;
            }
        }

        private decimal calculatePercentage(int value, XanderUI.XUISlider slider, bool doubleVal = false)
        {
            decimal percentage = slider.Percentage; //Have to put percent

            if (doubleVal)
                percentage *= 2;

            decimal calculatedFOV = value * (percentage / 100);

            calculatedFOV /= value;

            return (calculatedFOV);
        }

        private void FOVSlider_Click(object sender, EventArgs e)
        {
            FOVBox.Text = calculatePercentage(cfg.Width, FOVSlider).ToString();
        }

        private void FOVSlider_MouseDown(object sender, MouseEventArgs e)
        {
            FOVBox.Text = calculatePercentage(cfg.Width, FOVSlider).ToString();
        }

        private void FOVSlider_MouseMove(object sender, MouseEventArgs e)
        {
            FOVBox.Text = calculatePercentage(cfg.Width, FOVSlider).ToString();
        }

        private void FOVBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal val = Convert.ToDecimal(FOVBox.Text);
                    
                decimal calculatedVal = cfg.Width * val;

                int accVal = Convert.ToInt32(val * 100);

                //int percent = Convert.ToInt32(calculatedVal);

                FOVSlider.Percentage = accVal; //Have to put percent
            }
            catch
            {
                FOVSlider.Percentage = 100;
                FOVBox.Text = "1";
            }
        }

        private void SpeedSlider_Click(object sender, EventArgs e)
        {
            SpeedBox.Text = calculatePercentage(2, SpeedSlider, true).ToString();
        }

        private void SpeedSlider_MouseDown(object sender, MouseEventArgs e)
        {
            SpeedBox.Text = calculatePercentage(2, SpeedSlider, true).ToString();
        }

        private void SpeedSlider_MouseMove(object sender, MouseEventArgs e)
        {
            SpeedBox.Text = calculatePercentage(2, SpeedSlider, true).ToString();
        }

        private void Main_Leave(object sender, EventArgs e)
        {
            Bot.Enabled = false;
            Application.Exit();
        }

        private void AutoBhopCheck_Click(object sender, EventArgs e)
        {

        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
