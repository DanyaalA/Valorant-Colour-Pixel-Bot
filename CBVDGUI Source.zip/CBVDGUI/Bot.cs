﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CBVDGUI
{
    class Bot
    {
        //SIZE
        public static int xSize = 1920;
        public static int ySize = 1080;

        //FOV in pixels, smaller fov will result in faster update time
        public static int maxX = 200;
        public static int maxY = 150;

        // GAME
        public static float speed = 1.2f;
        public static int msBetweenShots = 200;
        public static int closeSize = 10;
        public static bool canShoot = true;

        // COLOR
        const int color = 0xaf2eaf; //0xb41515 = Red; 0xaf2eaf = purple
        const int colorVariation = 20;

        const double size = 60;  // DONT CHANGE
        const int maxCount = 5;

        static bool AutoShoot = true;
        static bool isOn = true; //Dead Switch
        public static bool Enabled = false;
        public static bool stopBot = false;
        static int snapDelay = 50;

        public static void Run()
        {
            Ini ini = new Ini();
            ini.CreateIni();

            Config conf = ini.Reader();

            int FOVX = Convert.ToInt32(conf.FOV * conf.Width);
            int FOVY = Convert.ToInt32(conf.FOV * conf.Height);
            maxX = FOVX;
            maxY = FOVY;

            AutoShoot = conf.AutoShoot;
            msBetweenShots = conf.ShootDelay;
            snapDelay = conf.SnapDelay;
            speed = conf.Speed;
            xSize = conf.Width;
            ySize = conf.Height;

            //string val = Console.ReadLine();
            //val = val.ToLower();

            //if (val == "n")
            //    reSnap = false;

            Thread t = new Thread(Update);
            //t.SetApartmentState(ApartmentState.STA);
            t.Start();

            Thread t2 = new Thread(KeyboardChecker);
            t2.SetApartmentState(ApartmentState.STA);
            t2.Start();

            //ConsoleLog();

            
        }

        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindow(string lpClassName,
    string lpWindowName);

        // Activate an application window.
        [DllImport("USER32.DLL")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);


        static void KeyboardChecker()
        {
            Ini ini = new Ini();
            Config cfg = ini.Reader();

            IntPtr calculatorHandle = FindWindow("VALORANT", "VALORANT");

            while (Enabled)
            {
                bool keyPress = false;

                switch (cfg.AimKey)
                {
                    case "LALT":
                        keyPress = (Keyboard.GetKeyStates(Key.LeftAlt) & KeyStates.Down) > 0;
                        break;
                    case "MOUSE1":
                        keyPress = Peripherals.Mouse.MouseButtonIsDown(1);
                        break;
                    case "MOUSE2":
                        keyPress = Peripherals.Mouse.MouseButtonIsDown(3);
                        break;
                    case "MOUSE3":
                        keyPress = Peripherals.Mouse.MouseButtonIsDown(2);
                        break;
                    case "XBUTTON1":
                        keyPress = Peripherals.Mouse.MouseButtonIsDown(4);
                        break;
                    case "XBUTTON2":
                        keyPress = Peripherals.Mouse.MouseButtonIsDown(5);
                        break;
                }


                if ((Keyboard.GetKeyStates(Key.Space) & KeyStates.Down) > 0 && cfg.Bhop)
                    System.Windows.Forms.SendKeys.SendWait("{L}");

                //if (CBDV.Peripherals.Mouse.MouseButtonIsDown(1))
                //Console.WriteLine("Mouise Down");

                //if ((Keyboard.GetKeyStates(Key.LeftAlt) & KeyStates.Down) > 0)
                if (keyPress)
                {
                    isOn = true;

                }
                else
                {
                    isOn = false;

                }

                if ((Keyboard.GetKeyStates(Key.F4) & KeyStates.Down) > 0)
                {
                    Enabled = !Enabled;
                    //ConsoleLog();


                    Thread.Sleep(500);
                }


                if (((Keyboard.GetKeyStates(Key.F5) & KeyStates.Down) > 0))
                {

                    //prevState = !prevState;

                    //ConsoleLog();
                    AutoShoot = !AutoShoot;
                    //ConsoleLog();



                }

                if (!Enabled)
                    break;
            }

        }

        static void ConsoleLog()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Enabled(F4): ");


            if (Enabled)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("True");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("False");
            }


            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();

            Console.Write("AutoShoot (F5): ");

            if (AutoShoot)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("On");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("Off");
            }

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("");
            Console.WriteLine("Hold Left Alt To Enable the bot");


        }

        static void Update()
        {
            System.DateTime lastshot = System.DateTime.Now;



            while (Enabled)
            {


                Task.Delay(1); // ANTI CRASH
                var l = PixelSearch(new Rectangle((xSize - maxX) / 2, (ySize - maxY) / 2, maxX, maxY), Color.FromArgb(color), colorVariation);

                // (Keyboard.GetKeyStates(Key.LeftAlt) & KeyStates.Down) > 0)

                if ((l.Length > 0) && isOn & Enabled)
                { // IF NOT ERROR
                    var q = l.OrderBy(t => t.Y).ToArray();

                    List<Vector2> forbidden = new List<Vector2>();

                    for (int i = 0; i < q.Length; i++)
                    {
                        Vector2 current = new Vector2(q[i].X, q[i].Y);
                        if (forbidden.Where(t => (t - current).Length() < size || Math.Abs(t.X - current.X) < size).Count() < 1)
                        { // TO NOT PLACE POINTS AT THE BODY
                            forbidden.Add(current);
                            if (forbidden.Count > maxCount)
                            {
                                break;
                            }
                        }
                    }

                    // DRAW
                    /*foreach (var c in forbidden) {
                        DrawRec((int)c.X, (int)c.Y - 20, 5, 5);
                    }*/

                    // SHOOTING
                    bool pressDown = false;
                    var closes = forbidden.Select(t => (t - new Vector2(xSize / 2, ySize / 2))).OrderBy(t => t.Length()).ElementAt(0) + new Vector2(1, 1);
                    if (closes.Length() < closeSize)
                    {
                        if (canShoot)
                        {
                            if (System.DateTime.Now.Subtract(lastshot).TotalMilliseconds > msBetweenShots)
                            {
                                lastshot = System.DateTime.Now;
                                pressDown = true;
                            }
                        }
                    }

                    Move((int)(closes.X * speed), (int)(closes.Y * speed), pressDown);

                    if (!Enabled)
                        break;
                }
            }
        }

        public static Image ResizeImage(Image imgToResize, Size destinationSize)
        {
            var originalWidth = imgToResize.Width;
            var originalHeight = imgToResize.Height;

            //how many units are there to make the original length
            var hRatio = (float)originalHeight / destinationSize.Height;
            var wRatio = (float)originalWidth / destinationSize.Width;

            //get the shorter side
            var ratio = Math.Min(hRatio, wRatio);

            var hScale = Convert.ToInt32(destinationSize.Height * ratio);
            var wScale = Convert.ToInt32(destinationSize.Width * ratio);

            //start cropping from the center
            var startX = (originalWidth - wScale) / 2;
            var startY = (originalHeight - hScale) / 2;

            //crop the image from the specified location and size
            var sourceRectangle = new Rectangle(startX, startY, wScale, hScale);

            //the future size of the image
            var bitmap = new Bitmap(destinationSize.Width, destinationSize.Height);

            //fill-in the whole bitmap
            var destinationRectangle = new Rectangle(0, 0, bitmap.Width, bitmap.Height);

            //generate the new image
            using (var g = Graphics.FromImage(bitmap))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.DrawImage(imgToResize, destinationRectangle, sourceRectangle, GraphicsUnit.Pixel);
            }

            return bitmap;

        }



        [DllImport("user32.dll")]
        static extern void mouse_event(int dwFlags, int dx, int dy, uint dwData,
UIntPtr dwExtraInfo);

        public static void Move(int xDelta, int yDelta, bool pressDown = false)
        {

            if (AutoShoot)
            {
                mouse_event(pressDown ? (MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP) : 0x0001, xDelta, yDelta, 0, UIntPtr.Zero);
            }
            else
            {
                mouse_event(pressDown ? (0x00) : 0x0001, xDelta, yDelta, 0, UIntPtr.Zero);
            }

            Thread.Sleep(snapDelay);

        }

        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;

        public static Point[] PixelSearch(Rectangle rect, Color Pixel_Color, int Shade_Variation) // REZ is for debugging
        {
            ArrayList points = new ArrayList();
            Bitmap RegionIn_Bitmap = new Bitmap(rect.Width, rect.Height, PixelFormat.Format24bppRgb);
            using (Graphics GFX = Graphics.FromImage(RegionIn_Bitmap))
            {
                GFX.CopyFromScreen(rect.X, rect.Y, 0, 0, rect.Size, CopyPixelOperation.SourceCopy);
            }
            BitmapData RegionIn_BitmapData = RegionIn_Bitmap.LockBits(new Rectangle(0, 0, RegionIn_Bitmap.Width, RegionIn_Bitmap.Height), ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            int[] Formatted_Color = new int[3] { Pixel_Color.B, Pixel_Color.G, Pixel_Color.R }; //bgr



            //var rnd = new Random();
            //var xval = rnd.Next(0, 1);

            unsafe
            {
                for (int y = 0; y < RegionIn_BitmapData.Height; y++)
                {
                    byte* row = (byte*)RegionIn_BitmapData.Scan0 + (y * RegionIn_BitmapData.Stride);
                    for (int x = 0; x < RegionIn_BitmapData.Width; x++)
                    {
                        if (row[x * 3] >= (Formatted_Color[0] - Shade_Variation) & row[x * 3] <= (Formatted_Color[0] + Shade_Variation)) //blue
                            if (row[(x * 3) + 1] >= (Formatted_Color[1] - Shade_Variation) & row[(x * 3) + 1] <= (Formatted_Color[1] + Shade_Variation)) //green
                                if (row[(x * 3) + 2] >= (Formatted_Color[2] - Shade_Variation) & row[(x * 3) + 2] <= (Formatted_Color[2] + Shade_Variation)) //red
                                    points.Add(new Point(x + rect.X, y + rect.Y));


                    }
                }
            }
            RegionIn_Bitmap.Dispose();
            return (Point[])points.ToArray(typeof(Point));
        }
    }
}
