﻿namespace CBVDGUI
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.SuperButton = new XanderUI.XUISuperButton();
            this.GeneralPanel = new System.Windows.Forms.Panel();
            this.xuiCustomGroupbox6 = new XanderUI.XUICustomGroupbox();
            this.AutoBhopCheck = new XanderUI.XUICheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.resHeightBox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.resWidthBox = new System.Windows.Forms.TextBox();
            this.AimPanel = new System.Windows.Forms.Panel();
            this.xuiCustomGroupbox4 = new XanderUI.XUICustomGroupbox();
            this.SpeedSlider = new XanderUI.XUISlider();
            this.FOVSlider = new XanderUI.XUISlider();
            this.SpeedBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.SnapDelayBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ShootDelayBox = new System.Windows.Forms.TextBox();
            this.FOVBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.xuiCustomGroupbox5 = new XanderUI.XUICustomGroupbox();
            this.AimKeyCombo = new System.Windows.Forms.ComboBox();
            this.AutoShootCheck = new XanderUI.XUICheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.MainSegment = new XanderUI.XUISegment();
            this.xuiCustomGroupbox1 = new XanderUI.XUICustomGroupbox();
            this.xuiRadio3 = new XanderUI.XUIRadio();
            this.xuiRadio4 = new XanderUI.XUIRadio();
            this.xuiCheckBox1 = new XanderUI.XUICheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.GeneralPanel.SuspendLayout();
            this.xuiCustomGroupbox6.SuspendLayout();
            this.AimPanel.SuspendLayout();
            this.xuiCustomGroupbox4.SuspendLayout();
            this.xuiCustomGroupbox5.SuspendLayout();
            this.xuiCustomGroupbox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // SuperButton
            // 
            this.SuperButton.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(116)))), ((int)(((byte)(79)))));
            this.SuperButton.ButtonImage = ((System.Drawing.Image)(resources.GetObject("SuperButton.ButtonImage")));
            this.SuperButton.ButtonSmoothing = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
            this.SuperButton.ButtonStyle = XanderUI.XUISuperButton.Style.RoundedEdges;
            this.SuperButton.ButtonText = "Start";
            this.SuperButton.CornerRadius = 5;
            this.SuperButton.Horizontal_Alignment = System.Drawing.StringAlignment.Center;
            this.SuperButton.HoverBackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(90)))), ((int)(((byte)(166)))));
            this.SuperButton.HoverTextColor = System.Drawing.Color.White;
            this.SuperButton.ImagePosition = XanderUI.XUISuperButton.imgPosition.Left;
            this.SuperButton.Location = new System.Drawing.Point(125, 295);
            this.SuperButton.Name = "SuperButton";
            this.SuperButton.SelectedBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(202)))), ((int)(((byte)(142)))));
            this.SuperButton.SelectedTextColor = System.Drawing.Color.White;
            this.SuperButton.Size = new System.Drawing.Size(100, 40);
            this.SuperButton.SuperSelected = false;
            this.SuperButton.TabIndex = 11;
            this.SuperButton.TextColor = System.Drawing.Color.White;
            this.SuperButton.Vertical_Alignment = System.Drawing.StringAlignment.Center;
            this.SuperButton.Click += new System.EventHandler(this.SuperButton_Click);
            // 
            // GeneralPanel
            // 
            this.GeneralPanel.Controls.Add(this.xuiCustomGroupbox1);
            this.GeneralPanel.Controls.Add(this.xuiCustomGroupbox6);
            this.GeneralPanel.Location = new System.Drawing.Point(7, 47);
            this.GeneralPanel.Name = "GeneralPanel";
            this.GeneralPanel.Size = new System.Drawing.Size(425, 241);
            this.GeneralPanel.TabIndex = 10;
            // 
            // xuiCustomGroupbox6
            // 
            this.xuiCustomGroupbox6.BorderColor = System.Drawing.Color.DodgerBlue;
            this.xuiCustomGroupbox6.BorderWidth = 1;
            this.xuiCustomGroupbox6.Controls.Add(this.AutoBhopCheck);
            this.xuiCustomGroupbox6.Controls.Add(this.label15);
            this.xuiCustomGroupbox6.Controls.Add(this.resHeightBox);
            this.xuiCustomGroupbox6.Controls.Add(this.label16);
            this.xuiCustomGroupbox6.Controls.Add(this.resWidthBox);
            this.xuiCustomGroupbox6.Location = new System.Drawing.Point(3, 3);
            this.xuiCustomGroupbox6.Name = "xuiCustomGroupbox6";
            this.xuiCustomGroupbox6.ShowText = true;
            this.xuiCustomGroupbox6.Size = new System.Drawing.Size(419, 92);
            this.xuiCustomGroupbox6.TabIndex = 5;
            this.xuiCustomGroupbox6.TabStop = false;
            this.xuiCustomGroupbox6.Text = "In-Game Resoloution";
            this.xuiCustomGroupbox6.TextColor = System.Drawing.Color.DodgerBlue;
            // 
            // AutoBhopCheck
            // 
            this.AutoBhopCheck.CheckboxCheckColor = System.Drawing.Color.White;
            this.AutoBhopCheck.CheckboxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(250)))));
            this.AutoBhopCheck.CheckboxHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.AutoBhopCheck.CheckboxStyle = XanderUI.XUICheckBox.Style.Material;
            this.AutoBhopCheck.Checked = false;
            this.AutoBhopCheck.ForeColor = System.Drawing.Color.Black;
            this.AutoBhopCheck.Location = new System.Drawing.Point(177, 27);
            this.AutoBhopCheck.Name = "AutoBhopCheck";
            this.AutoBhopCheck.Size = new System.Drawing.Size(100, 20);
            this.AutoBhopCheck.TabIndex = 22;
            this.AutoBhopCheck.Text = "Auto Bhop";
            this.AutoBhopCheck.TickThickness = 2;
            this.AutoBhopCheck.Click += new System.EventHandler(this.AutoBhopCheck_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 56);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "Height:";
            // 
            // resHeightBox
            // 
            this.resHeightBox.Location = new System.Drawing.Point(51, 53);
            this.resHeightBox.Name = "resHeightBox";
            this.resHeightBox.Size = new System.Drawing.Size(100, 20);
            this.resHeightBox.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "Width:";
            // 
            // resWidthBox
            // 
            this.resWidthBox.Location = new System.Drawing.Point(51, 27);
            this.resWidthBox.Name = "resWidthBox";
            this.resWidthBox.Size = new System.Drawing.Size(100, 20);
            this.resWidthBox.TabIndex = 1;
            // 
            // AimPanel
            // 
            this.AimPanel.Controls.Add(this.xuiCustomGroupbox4);
            this.AimPanel.Controls.Add(this.xuiCustomGroupbox5);
            this.AimPanel.Location = new System.Drawing.Point(454, 48);
            this.AimPanel.Name = "AimPanel";
            this.AimPanel.Size = new System.Drawing.Size(425, 241);
            this.AimPanel.TabIndex = 9;
            // 
            // xuiCustomGroupbox4
            // 
            this.xuiCustomGroupbox4.BorderColor = System.Drawing.Color.DodgerBlue;
            this.xuiCustomGroupbox4.BorderWidth = 1;
            this.xuiCustomGroupbox4.Controls.Add(this.SpeedSlider);
            this.xuiCustomGroupbox4.Controls.Add(this.FOVSlider);
            this.xuiCustomGroupbox4.Controls.Add(this.SpeedBox);
            this.xuiCustomGroupbox4.Controls.Add(this.label9);
            this.xuiCustomGroupbox4.Controls.Add(this.label10);
            this.xuiCustomGroupbox4.Controls.Add(this.SnapDelayBox);
            this.xuiCustomGroupbox4.Controls.Add(this.label11);
            this.xuiCustomGroupbox4.Controls.Add(this.ShootDelayBox);
            this.xuiCustomGroupbox4.Controls.Add(this.FOVBox);
            this.xuiCustomGroupbox4.Controls.Add(this.label12);
            this.xuiCustomGroupbox4.Location = new System.Drawing.Point(3, 3);
            this.xuiCustomGroupbox4.Name = "xuiCustomGroupbox4";
            this.xuiCustomGroupbox4.ShowText = true;
            this.xuiCustomGroupbox4.Size = new System.Drawing.Size(415, 135);
            this.xuiCustomGroupbox4.TabIndex = 4;
            this.xuiCustomGroupbox4.TabStop = false;
            this.xuiCustomGroupbox4.Text = "In-Game Resoloution";
            this.xuiCustomGroupbox4.TextColor = System.Drawing.Color.DodgerBlue;
            // 
            // SpeedSlider
            // 
            this.SpeedSlider.BarThickness = 4;
            this.SpeedSlider.BigStepIncrement = 10;
            this.SpeedSlider.FilledColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(119)))), ((int)(((byte)(215)))));
            this.SpeedSlider.KnobColor = System.Drawing.Color.Gray;
            this.SpeedSlider.KnobImage = null;
            this.SpeedSlider.Location = new System.Drawing.Point(45, 49);
            this.SpeedSlider.Name = "SpeedSlider";
            this.SpeedSlider.Percentage = 50;
            this.SpeedSlider.QuickHopping = true;
            this.SpeedSlider.Size = new System.Drawing.Size(258, 23);
            this.SpeedSlider.SliderStyle = XanderUI.XUISlider.Style.MacOS;
            this.SpeedSlider.TabIndex = 20;
            this.SpeedSlider.Text = "xuiSlider2";
            this.SpeedSlider.UnfilledColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(169)))), ((int)(((byte)(219)))));
            this.SpeedSlider.Click += new System.EventHandler(this.SpeedSlider_Click);
            this.SpeedSlider.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SpeedSlider_MouseDown);
            this.SpeedSlider.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SpeedSlider_MouseMove);
            // 
            // FOVSlider
            // 
            this.FOVSlider.BarThickness = 4;
            this.FOVSlider.BigStepIncrement = 10;
            this.FOVSlider.FilledColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(119)))), ((int)(((byte)(215)))));
            this.FOVSlider.KnobColor = System.Drawing.Color.Gray;
            this.FOVSlider.KnobImage = null;
            this.FOVSlider.Location = new System.Drawing.Point(45, 19);
            this.FOVSlider.Name = "FOVSlider";
            this.FOVSlider.Percentage = 50;
            this.FOVSlider.QuickHopping = true;
            this.FOVSlider.Size = new System.Drawing.Size(258, 23);
            this.FOVSlider.SliderStyle = XanderUI.XUISlider.Style.MacOS;
            this.FOVSlider.TabIndex = 16;
            this.FOVSlider.Text = "xuiSlider1";
            this.FOVSlider.UnfilledColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(169)))), ((int)(((byte)(219)))));
            this.FOVSlider.Click += new System.EventHandler(this.FOVSlider_Click);
            this.FOVSlider.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FOVSlider_MouseDown);
            this.FOVSlider.MouseMove += new System.Windows.Forms.MouseEventHandler(this.FOVSlider_MouseMove);
            // 
            // SpeedBox
            // 
            this.SpeedBox.Location = new System.Drawing.Point(306, 47);
            this.SpeedBox.Name = "SpeedBox";
            this.SpeedBox.Size = new System.Drawing.Size(100, 20);
            this.SpeedBox.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 54);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Speed:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 104);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Snap Delay: ";
            // 
            // SnapDelayBox
            // 
            this.SnapDelayBox.Location = new System.Drawing.Point(76, 101);
            this.SnapDelayBox.Name = "SnapDelayBox";
            this.SnapDelayBox.Size = new System.Drawing.Size(100, 20);
            this.SnapDelayBox.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 78);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Shoot Delay:";
            // 
            // ShootDelayBox
            // 
            this.ShootDelayBox.Location = new System.Drawing.Point(76, 75);
            this.ShootDelayBox.Name = "ShootDelayBox";
            this.ShootDelayBox.Size = new System.Drawing.Size(100, 20);
            this.ShootDelayBox.TabIndex = 8;
            // 
            // FOVBox
            // 
            this.FOVBox.Location = new System.Drawing.Point(306, 21);
            this.FOVBox.Name = "FOVBox";
            this.FOVBox.Size = new System.Drawing.Size(100, 20);
            this.FOVBox.TabIndex = 7;
            this.FOVBox.TextChanged += new System.EventHandler(this.FOVBox_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 2;
            this.label12.Text = "FOV:";
            // 
            // xuiCustomGroupbox5
            // 
            this.xuiCustomGroupbox5.BorderColor = System.Drawing.Color.DodgerBlue;
            this.xuiCustomGroupbox5.BorderWidth = 1;
            this.xuiCustomGroupbox5.Controls.Add(this.AimKeyCombo);
            this.xuiCustomGroupbox5.Controls.Add(this.AutoShootCheck);
            this.xuiCustomGroupbox5.Controls.Add(this.label13);
            this.xuiCustomGroupbox5.Controls.Add(this.label14);
            this.xuiCustomGroupbox5.Location = new System.Drawing.Point(3, 144);
            this.xuiCustomGroupbox5.Name = "xuiCustomGroupbox5";
            this.xuiCustomGroupbox5.ShowText = true;
            this.xuiCustomGroupbox5.Size = new System.Drawing.Size(415, 86);
            this.xuiCustomGroupbox5.TabIndex = 3;
            this.xuiCustomGroupbox5.TabStop = false;
            this.xuiCustomGroupbox5.Text = "Other";
            this.xuiCustomGroupbox5.TextColor = System.Drawing.Color.DodgerBlue;
            // 
            // AimKeyCombo
            // 
            this.AimKeyCombo.FormattingEnabled = true;
            this.AimKeyCombo.Items.AddRange(new object[] {
            "LALT",
            "MOUSE1",
            "MOUSE2",
            "MOUSE3",
            "XBUTTON1",
            "XBUTTON2"});
            this.AimKeyCombo.Location = new System.Drawing.Point(76, 49);
            this.AimKeyCombo.Name = "AimKeyCombo";
            this.AimKeyCombo.Size = new System.Drawing.Size(121, 21);
            this.AimKeyCombo.TabIndex = 22;
            // 
            // AutoShootCheck
            // 
            this.AutoShootCheck.CheckboxCheckColor = System.Drawing.Color.White;
            this.AutoShootCheck.CheckboxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(250)))));
            this.AutoShootCheck.CheckboxHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.AutoShootCheck.CheckboxStyle = XanderUI.XUICheckBox.Style.Material;
            this.AutoShootCheck.Checked = false;
            this.AutoShootCheck.ForeColor = System.Drawing.Color.White;
            this.AutoShootCheck.Location = new System.Drawing.Point(76, 22);
            this.AutoShootCheck.Name = "AutoShootCheck";
            this.AutoShootCheck.Size = new System.Drawing.Size(100, 20);
            this.AutoShootCheck.TabIndex = 20;
            this.AutoShootCheck.TickThickness = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 51);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "Aim Key:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "Auto Shoot:";
            // 
            // MainSegment
            // 
            this.MainSegment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MainSegment.Items = "General, Aim";
            this.MainSegment.Location = new System.Drawing.Point(7, 12);
            this.MainSegment.Name = "MainSegment";
            this.MainSegment.SegmentActiveTextColor = System.Drawing.Color.White;
            this.MainSegment.SegmentBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(135)))));
            this.MainSegment.SegmentColor = System.Drawing.Color.White;
            this.MainSegment.SegmentInactiveTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(210)))), ((int)(((byte)(210)))));
            this.MainSegment.SegmentStyle = XanderUI.XUISegment.Style.Material;
            this.MainSegment.SelectedIndex = 0;
            this.MainSegment.Size = new System.Drawing.Size(433, 30);
            this.MainSegment.TabIndex = 8;
            this.MainSegment.Text = "xuiSegment1";
            this.MainSegment.Click += new System.EventHandler(this.MainSegment_Click);
            // 
            // xuiCustomGroupbox1
            // 
            this.xuiCustomGroupbox1.BorderColor = System.Drawing.Color.DodgerBlue;
            this.xuiCustomGroupbox1.BorderWidth = 1;
            this.xuiCustomGroupbox1.Controls.Add(this.xuiRadio3);
            this.xuiCustomGroupbox1.Controls.Add(this.xuiRadio4);
            this.xuiCustomGroupbox1.Controls.Add(this.xuiCheckBox1);
            this.xuiCustomGroupbox1.Location = new System.Drawing.Point(3, 101);
            this.xuiCustomGroupbox1.Name = "xuiCustomGroupbox1";
            this.xuiCustomGroupbox1.ShowText = true;
            this.xuiCustomGroupbox1.Size = new System.Drawing.Size(419, 114);
            this.xuiCustomGroupbox1.TabIndex = 27;
            this.xuiCustomGroupbox1.TabStop = false;
            this.xuiCustomGroupbox1.Text = "Other";
            this.xuiCustomGroupbox1.TextColor = System.Drawing.Color.DodgerBlue;
            // 
            // xuiRadio3
            // 
            this.xuiRadio3.Checked = false;
            this.xuiRadio3.ForeColor = System.Drawing.Color.Black;
            this.xuiRadio3.Location = new System.Drawing.Point(133, 19);
            this.xuiRadio3.Name = "xuiRadio3";
            this.xuiRadio3.RadioColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(250)))));
            this.xuiRadio3.RadioHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.xuiRadio3.RadioStyle = XanderUI.XUIRadio.Style.Material;
            this.xuiRadio3.Size = new System.Drawing.Size(100, 16);
            this.xuiRadio3.TabIndex = 26;
            this.xuiRadio3.Text = "Red";
            // 
            // xuiRadio4
            // 
            this.xuiRadio4.Checked = false;
            this.xuiRadio4.ForeColor = System.Drawing.Color.Black;
            this.xuiRadio4.Location = new System.Drawing.Point(133, 42);
            this.xuiRadio4.Name = "xuiRadio4";
            this.xuiRadio4.RadioColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(250)))));
            this.xuiRadio4.RadioHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.xuiRadio4.RadioStyle = XanderUI.XUIRadio.Style.Material;
            this.xuiRadio4.Size = new System.Drawing.Size(100, 16);
            this.xuiRadio4.TabIndex = 25;
            this.xuiRadio4.Text = "Purple";
            // 
            // xuiCheckBox1
            // 
            this.xuiCheckBox1.CheckboxCheckColor = System.Drawing.Color.White;
            this.xuiCheckBox1.CheckboxColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(250)))));
            this.xuiCheckBox1.CheckboxHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(55)))), ((int)(((byte)(98)))));
            this.xuiCheckBox1.CheckboxStyle = XanderUI.XUICheckBox.Style.Material;
            this.xuiCheckBox1.Checked = false;
            this.xuiCheckBox1.ForeColor = System.Drawing.Color.Black;
            this.xuiCheckBox1.Location = new System.Drawing.Point(10, 19);
            this.xuiCheckBox1.Name = "xuiCheckBox1";
            this.xuiCheckBox1.Size = new System.Drawing.Size(100, 20);
            this.xuiCheckBox1.TabIndex = 22;
            this.xuiCheckBox1.Text = "Auto Bhop";
            this.xuiCheckBox1.TickThickness = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(74, 367);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(213, 115);
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1091, 600);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.GeneralPanel);
            this.Controls.Add(this.AimPanel);
            this.Controls.Add(this.MainSegment);
            this.Controls.Add(this.SuperButton);
            this.Name = "Main";
            this.Text = "Main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.Load += new System.EventHandler(this.Main_Load);
            this.Leave += new System.EventHandler(this.Main_Leave);
            this.GeneralPanel.ResumeLayout(false);
            this.xuiCustomGroupbox6.ResumeLayout(false);
            this.xuiCustomGroupbox6.PerformLayout();
            this.AimPanel.ResumeLayout(false);
            this.xuiCustomGroupbox4.ResumeLayout(false);
            this.xuiCustomGroupbox4.PerformLayout();
            this.xuiCustomGroupbox5.ResumeLayout(false);
            this.xuiCustomGroupbox5.PerformLayout();
            this.xuiCustomGroupbox1.ResumeLayout(false);
            this.xuiCustomGroupbox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private XanderUI.XUISuperButton SuperButton;
        private System.Windows.Forms.Panel GeneralPanel;
        private XanderUI.XUICustomGroupbox xuiCustomGroupbox6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox resHeightBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox resWidthBox;
        private System.Windows.Forms.Panel AimPanel;
        private XanderUI.XUICustomGroupbox xuiCustomGroupbox4;
        private System.Windows.Forms.TextBox SpeedBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox SnapDelayBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox ShootDelayBox;
        private System.Windows.Forms.TextBox FOVBox;
        private System.Windows.Forms.Label label12;
        private XanderUI.XUICustomGroupbox xuiCustomGroupbox5;
        private XanderUI.XUICheckBox AutoShootCheck;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private XanderUI.XUISegment MainSegment;
        private System.Windows.Forms.ComboBox AimKeyCombo;
        private XanderUI.XUISlider FOVSlider;
        private XanderUI.XUISlider SpeedSlider;
        private XanderUI.XUICheckBox AutoBhopCheck;
        private XanderUI.XUICustomGroupbox xuiCustomGroupbox1;
        private XanderUI.XUIRadio xuiRadio3;
        private XanderUI.XUIRadio xuiRadio4;
        private XanderUI.XUICheckBox xuiCheckBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}